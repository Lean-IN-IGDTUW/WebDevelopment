
let points=sessionStorage.getItem("points");

let usertime=sessionStorage.getItem("time");
document.querySelector(".points").innerHTML=points;
document.querySelector(".time").innerHTML=usertime;